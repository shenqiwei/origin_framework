<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/1/9
 * Time: 16:40
 */

namespace Origin\Kernel\File;


class File
{

}