<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/2/23
 * Time: 9:38
 */

namespace Origin\Kernel\File;


class Upload
{

}