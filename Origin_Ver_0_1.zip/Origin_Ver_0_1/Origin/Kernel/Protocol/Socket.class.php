<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/1/9
 * Time: 11:03
 */

namespace Ring\Kernel\Protocol;


class Socket
{

}