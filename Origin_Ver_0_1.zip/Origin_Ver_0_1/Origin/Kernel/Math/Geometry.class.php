<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/1/11
 * Time: 15:42
 */

namespace Origin\Kernel\Math;


class Geometry
{
}