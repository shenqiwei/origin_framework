<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/1/11
 * Time: 10:22
 */
namespace Origin\Kernel\Math;

class Algebra
{
}