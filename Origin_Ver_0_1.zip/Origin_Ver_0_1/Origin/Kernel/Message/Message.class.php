<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/1/9
 * Time: 16:41
 */

namespace Origin\Kernel\Message;


class Message
{

}