<?php
/**
 * coding: utf-8 *
 * system OS: windows2008 *
 * work Tools:Phpstorm *
 * language Ver: php7.1 *
 * agreement: PSR-1 to PSR-11 *
 * filename: IoC.Origin.Kernel.Graph.View *
 * version: 1.0 *
 * structure: common framework *
 * email: cheerup.shen@foxmail.com *
 * designer: 沈启威 *
 * developer: 沈启威 *
 * partner: 沈启威 *
 * create Time: 2017/02/03 16:04
 * update Time: 2017/02/03 16:04
 * chinese Context: IoC 变量过滤封装类
 */
namespace Origin\Kernel\Graph;
# 调用标签解释器
//use Origin\Kernel\Mark\Label;
/**
 * 模板调度类
 */
class View
{
    /**
     * 模板文件夹信息
     * @var string $_Dir
    */
    private $_Dir = null;
    /**
     * 模板页名称信息
     * @var string $_Page
    */
    private $_Page = null;
    /**
     * 构造方法用于获取模板对象
     * @access public
     * @param string $dir
     * @param string $page
     */
    function __construct($dir, $page)
    {
        $this->_Dir = $dir;
        $this->_Page = $page;
    }
    /**
     * 模板页加载方法
     * @access public
     * @param array $param
     * @return null
    */
    function view($param)
    {
        # 转化文件路径
        $_guide = explode('/',$this->_Dir);
        # 判断结构模型
        $_dir = C('DEFAULT_APPLICATION');
        # 判断引导路径中是否存在多级文件
        if(count($_guide) > 1){
            for($i=0; $i<count($_guide);$i++){
                if(($i+1) == count($_guide))
                    $this->_Dir = $_guide[count($_guide)-1];
                else
                    $_dir = $_guide[$i].'/';
            }
        }
        # 获取应用目录
        $_url = str_replace('/', SLASH, C('ROOT_APPLICATION').$_dir);
        # 判断应用目录是否有效
        if(is_dir($_url)){
            # 获得前台模板目录
            $_url_view = str_replace('/', SLASH, $_url.C('APPLICATION_VIEW'));
            # 判断前台模板目录是否有效
            if(is_dir($_url_view)){
                # 判断应用控制器对应前台模板目录是否有效
                if(is_dir($_url_view.$this->_Dir)){
                    # 调用模板
                    $_page = $_url_view.$this->_Dir.SLASH.$this->_Page.C('VIEW_SUFFIX');
                    if(is_file($_page)){
                        Import('Mark:Label');
                        $_label = new \Origin\Kernel\Mark\Label($_page, $param);
                        echo($_label->execute());
                    }else{
                        # 异常提示：该对象模板不存在
                        try{
                            throw new \Exception('Origin Class Error: The object template '.$_page.' does not exist');
                        }catch(\Exception $e){
                            echo($e->getMessage());
                            exit();
                        }
                    }
                }else{
                    //这里不做异常处理，下一个版本将引入控制器及空函数导向
                }
            }else{
                # 异常提示：请在当前路径下创建view文件夹
                try{
                    throw new \Exception('Origin Class Error: Please create the (view) folder under the current path:'.$_url);
                }catch(\Exception $e){
                    echo($e->getMessage());
                    exit();
                }
            }
        }else{
            # 异常提示：主文件夹地址不存在
            try{
                throw new \Exception('Origin Class Error: The folder address '.$_url.' does not exist');
            }catch(\Exception $e){
                echo($e->getMessage());
                exit();
            }
        }
        return null;
    }
}