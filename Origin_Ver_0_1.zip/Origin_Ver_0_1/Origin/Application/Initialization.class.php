<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/1/10
 * Time: 11:23
 */

namespace Origin\Application;


class Initialization
{

}