<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/1/16
 * Time: 18:00
 */

namespace Apply\OriginX\Controller;

use Origin\Controller;

class IndexController extends Controller
{

    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        $_verify = V(300,120);
        $_verify->math();
    }

    function get()
    {
        echo('结果:'.Session('Verify'));
    }
}